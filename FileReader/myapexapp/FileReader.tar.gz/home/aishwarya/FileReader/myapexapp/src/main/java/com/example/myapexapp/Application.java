/**
 * Put your copyright and license info here.
 */
package com.example.myapexapp;

import java.io.File;
import java.util.Map;

import org.apache.apex.malhar.lib.fs.FSRecordReaderModule;
import org.apache.apex.malhar.lib.fs.GenericFileOutputOperator.StringFileOutputOperator;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import com.google.common.collect.Maps;
import com.datatorrent.api.DAG;
import com.datatorrent.api.StreamingApplication;
import com.datatorrent.api.annotation.ApplicationAnnotation;
import com.datatorrent.contrib.formatter.CsvFormatter;
import com.datatorrent.contrib.parser.CsvParser;
import com.datatorrent.lib.transform.TransformOperator;
import com.datatorrent.lib.filter.FilterOperator;


import java.util.Arrays;

@ApplicationAnnotation(name="MyFirstApplication")
public class Application implements StreamingApplication
{

  @Override
  public void populateDAG(DAG dag, Configuration conf)
  {
    FSRecordReaderModule sensorDataReader = dag.addModule("sensorDataReader",FSRecordReaderModule.class);
    CsvParser csvParser = dag.addOperator("csvParser",CsvParser.class);
    FilterOperator filterOperator = dag.addOperator("filterOperator", new FilterOperator());

    CsvFormatter selectedFormatter = dag.addOperator("selectedFormatter", new CsvFormatter());
    CsvFormatter rejectedFormatter = dag.addOperator("rejectedFormatter", new CsvFormatter());


    StringFileOutputOperator selectedOutput = dag.addOperator("selectedOutput", new StringFileOutputOperator());
    StringFileOutputOperator rejectedOutput = dag.addOperator("rejectedOutput", new StringFileOutputOperator());
    //CsvFormatter formatter = dag.addOperator("formatter",new CsvFormatter());
    //StringFileOutputOperator fileOutput = dag.addOperator("fileOutput",new StringFileOutputOperator());

    dag.addStream("sensordata", sensorDataReader.records, csvParser.in);
    dag.addStream("pojo", csvParser.out, filterOperator.input);

    dag.addStream("pojoSelected", filterOperator.truePort, selectedFormatter.in);
    dag.addStream("pojoRejected", filterOperator.falsePort, rejectedFormatter.in);

    dag.addStream("csvSelected", selectedFormatter.out, selectedOutput.input);
    dag.addStream("csvRejected", rejectedFormatter.out, rejectedOutput.input);

  }
}
