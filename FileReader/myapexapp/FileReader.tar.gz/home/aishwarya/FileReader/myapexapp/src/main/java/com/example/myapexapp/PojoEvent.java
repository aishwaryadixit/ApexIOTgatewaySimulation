package com.example.myapexapp;

/**
 * Created by aishwarya on 12/1/17.
 */
public class PojoEvent {

    private String id;
    private String time;
    private int temperature;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id =id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) { this.temperature = temperature;}
}
